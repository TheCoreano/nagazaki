CREATE TABLE carro (
  id INT AUTO_INCREMENT PRIMARY KEY,
  modelo VARCHAR(128),
  marca VARCHAR(128),
  quilometragem INT,
  cambio VARCHAR(64),
  combustivel VARCHAR(64),
  cor VARCHAR(64),
  ano INT,
  cidade VARCHAR(127),
  preco INT
) Engine=InnoDB DEFAULT CHARSET=utf8


CREATE TABLE user (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(128),
  senha VARCHAR(128),
  endereco VARCHAR(128),
  cidade VARCHAR(127)
) Engine=InnoDB DEFAULT CHARSET=utf8
