<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DAO2 extends CI_Model{
    
    public function __construct(){
        parent::__construct();
        $this->load->database();
    }
    
    public function insert($dd = null) {
        if ($dd != null){
            $this->db->insert('user', $dd);   
        }
    }

    public function removeUser($id = null){
        if($id != null) {
            $this->db->where('id', $id)->delete('user');
        }
    }

  public function list($sort='id',$order='asc'){
      $this->db->order_by($sort, $order);
      $query = $this->db->get('user');
      if ($query->num_rows() > 0) return $query->result();
      else return null;
  }
}