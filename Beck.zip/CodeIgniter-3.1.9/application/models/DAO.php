<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class DAO extends CI_Model{
    
    public function __construct(){
        parent::__construct();
        $this->load->database();
    }
    
    public function insert($dados = null) {
        if ($dados != null){
            $this->db->insert('carro', $dados);   
        }
    }

    public function removeModel($model = null){
        if($model != null) {
            $this->db->where('modelo', $model)->delete('carro');
        }
    }

    public function removeBrand($brand = null){
        if($brand != null) {
            $this->db->where('marca', $brand)->delete('carro');
        }
    } 

  public function list($sort='id',$order='asc'){
      $this->db->order_by($sort, $order);
      $query = $this->db->get('carro');
      if ($query->num_rows() > 0) return $query->result();
      else return null;
  }
}
