<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class controller extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
        $this->load->helper('array');
        $this->load->model('DAO','carro');
        $this->load->model('DAO2','user');
	}

	public function index(){
    $this->load->model('DAO','carro','DAO2','user');
	$dados['carro'] = $this->carro->list();
	$dados['user'] = $this->user->list();
    $this->load->view('index.php',$dados);
  }

  	public function cadastro(){
    	$this->load->view('cadastro.php');
  	}

  	public function login(){
  		$this->load->view('login.php');
  		$dados = elements(['login', 'senha'], $this->input->post());
  		$true = false;
  		$this->load->model('DAO2');
  		$this->load->helper('url');
  		if($dados['login'] == "admin" && $dados['senha'] == "admin"){
  			$_SESSION['login'] = "admin";
	    	$_SESSION['senha'] = "admin";
  			redirect('controller/');
  		}
  		else {  			
	  		foreach ($this->DAO2->list() as $key) {
	  			if($key->nome == $dados['login']){
	  				if ($key->senha == $dados['senha']) {
	  					$this->load->library('session');
	  					$lg = $key->nome;
	    				$sh = $key->senha;
	    				$_SESSION['login'] = $lg;
	    				$_SESSION['senha'] = $sh;
	    				$_SESSION['cidade'] = $key->cidade;
	    				$true = true;
	  					redirect('controller/user');	
	  				}
	  			}
	  		}
  		}
  	}
  	public function user(){
  		$this->load->model('DAO','carro');
		$dados['carro'] = $this->carro->list();
    	$this->load->view('user.php',$dados);
  	}

  	public function insertUser(){
		$this->verify($this);
		#if($this->form_validation->run()){
			$dd = elements(['nome', 'senha', 'endereco', 'cidade'], $this->input->post());
			$this->load->model('DAO2');
			$this->DAO2->insert($dd);
			$this->load->view('login.php');
		#}
	}

	public function insertzin(){
		$this->verify($this);
		if($this->form_validation->run()){
			$dados = elements(['modelo', 'marca', 'quilometragem', 'cambio', 'combustivel', 'cor', 'ano', 'cidade', 'preco'], $this->input->post());
			$this->load->model('DAO');
			$this->DAO->insert($dados);
		}
		$this->index();	
	}

	public function removeModel(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('modelo', 'Modelo', 'required|max_length[128]|trim');
		if($this->form_validation->run()){
			$dados = elements(array('modelo'),$this->input->post());
  			$this->load->model('DAO');
  			$this->DAO->removeModel($dados['modelo']);
		}
		$this->index();
	}


	public function removeBrand(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('marca', 'Marca', 'required|in_list[Acura,Audi,BMW,Chevrolet,Citroën,Dodge,Ferrari,Fiat,Ford,Honda,Hyundai,Jaguar,Jeep,Kia Motors,Koenigsegg,Lamborghini,Land Rover,Lexus,Mazda,Mercedez-Benz,MINI,Mitsubishi,Nissan,Peugeot,Porsche,Renault,Seat,Subaru,Suzuki,Toyota,Volkswagen,Volvo]');
		if($this->form_validation->run()){
			$dados = elements(array('marca'),$this->input->post());
  			$this->load->model('DAO');
  			$this->DAO->removeBrand($dados['marca']);
		}
		$this->index();
	}
	
	public function removeUser(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('id', 'Id', 'required|max_length[128]|trim');
		if($this->form_validation->run()){
			$dados = elements(array('id'),$this->input->post());
  			$this->load->model('DAO2');
  			$this->DAO2->removeUser($dados['id']);
		}
		$this->index();
	}

  	public function verify(){
  		$this->load->library('form_validation');
		echo validation_errors();
		$this->form_validation->set_rules('modelo', 'Modelo', 'required|max_length[128]|trim');
		$this->form_validation->set_rules('marca', 'Marca', 'required|in_list[Acura,Audi,BMW,Chevrolet,Citroën,Dodge,Ferrari,Fiat,Ford,Honda,Hyundai,Jaguar,Jeep,Kia Motors,Koenigsegg,Lamborghini,Land Rover,Lexus,Mazda,Mercedez-Benz,MINI,Mitsubishi,Nissan,Peugeot,Porsche,Renault,Seat,Subaru,Suzuki,Toyota,Volkswagen,Volvo]');
		$this->form_validation->set_rules('quilometragem', 'Quilometragem', 'required|trim|is_natural');
		$this->form_validation->set_rules('cambio', 'Câmbio', 'required|in_list[Manual,Automático]');
		$this->form_validation->set_rules('combustivel', 'Combustível', 'required|in_list[Gasolina,Álcool,Diesel,Flex]');
		$this->form_validation->set_rules('cor', 'Cor', 'required|max_length[64]|trim|strtolower|ucwords');
		$this->form_validation->set_rules('ano', 'Ano', 'required|trim|greater_than_equal_to[1750]|less_than_equal_to['.date('Y').']');
		$this->form_validation->set_rules('cidade', 'Cidade', 'required|max_length[127]|ucwords');
		$this->form_validation->set_rules('preco', 'Preco', 'required|trim|greater_than_equal_to[5000]|less_than_equal_to[900000]');
  	}

  	
}
