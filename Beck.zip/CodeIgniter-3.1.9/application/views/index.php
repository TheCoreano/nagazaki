<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Index</title>

  <style type="text/css">

  ::selection { background-color: #E13300; color: white; }
  ::-moz-selection { background-color: #E13300; color: white; }

  body {
    background-color: #fff;
    margin: 40px;
    font: 13px/20px normal Helvetica, Arial, sans-serif;
    color: #4F5155;
  }

  a {
    color: #003399;
    background-color: transparent;
    font-weight: normal;
  }

  h1 {
    color: #444;
    background-color: transparent;
    border-bottom: 1px solid #D0D0D0;
    font-size: 19px;
    font-weight: normal;
    margin: 0 0 14px 0;
    padding: 14px 15px 10px 15px;
  }

  code {
    font-family: Consolas, Monaco, Courier New, Courier, monospace;
    font-size: 12px;
    background-color: #f9f9f9;
    border: 1px solid #D0D0D0;
    color: #002166;
    display: block;
    margin: 14px 0 14px 0;
    padding: 12px 10px 12px 10px;
  }

  #body {
    margin: 0 15px 0 15px;
  }

  p.footer {
    text-align: right;
    font-size: 11px;
    border-top: 1px solid #D0D0D0;
    line-height: 32px;
    padding: 0 10px 0 10px;
    margin: 20px 0 0 0;
  }

  #container {
    margin: 10px;
    border: 1px solid #D0D0D0;
    box-shadow: 0 0 8px #D0D0D0;
  }
  </style>
</head>
<body>
<!-- LIST USERS GENERAL -->
<div id="container">
  <center><h1>LIST USERS</h1></center>
    <?php if($user != NULL){ ?>
      <center><table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Endereço</th>
          <th>Cidade</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($user as $atual){?>
        <tr>
            <td><?php echo $atual->id;?></td>
            <td><?php echo $atual->endereco;?></td>
            <td><?php echo $atual->nome;?></td>
            <td><?php echo $atual->cidade;?></td>
        </tr>
        </tbody>
        <?php }?>
      </table>
      </center>
    <?php } else { ?>
      <center><h2> Nenhum usuário cadastrado. </h2></center>

    <?php } ?>
</div>

<!-- LIST CARS GENERAL -->
<div id="container">
  <center><h1>LIST CARS</h1></center>
    <?php if($carro != NULL){ ?>
      <center><table>
      <thead>
        <tr>
          <th>Modelo</th>
          <th>Marca</th>
          <th>Quilometragem</th>
          <th>Cor</th>
          <th>Ano</th>
          <th>Combustivel</th>
          <th>Cambio</th>
          <th>Cidade</th>
          <th>Preço</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($carro as $atual){?>
        <tr>
            <td><?php echo $atual->modelo;?></td>
            <td><?php echo $atual->marca;?></td>
            <td><?php echo $atual->quilometragem;?></td>
            <td><?php echo $atual->cor;?></td>
            <td><?php echo $atual->ano;?></td>
            <td><?php echo $atual->combustivel;?></td>
            <td><?php echo $atual->cambio;?></td>
            <td><?php echo $atual->cidade;?></td>
            <td><?php echo $atual->preco;?></td>
        </tr>
        </tbody>
        <?php }?>
      </table>
      </center>
    <?php } else { ?>
      <center><h2> Nenhuma carro cadastrado. </h2></center>

    <?php } ?>
</div>

<!-- CAR EXPENSIVE  -->
<div id="container">
  <center><h1>SHOW EXPENSIVE</h1></center>
    <?php if($carro != NULL ){
      $bigger = NULL;
      $smaller = NULL;
      $expensive = 0;
      $cheap = 10000000;
      $final = null;
      foreach ($carro as $atual){
        if($atual->preco >= $expensive) {
          $bigger = $atual;
          $expensive = $atual->preco;
        }
      }
    ?>
      <center><h3><?php echo $bigger->modelo." - Valor: ". $expensive ?> </h3></center>
    <?php } else{ ?>
      <center><h2>Nenhum automovel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CAR CHEAP  -->
<div id="container">
  <center><h1>SHOW CHEAP</h1></center>
    <?php if($carro != NULL ){
      $bigger = NULL;
      $smaller = NULL;
      $expensive = 0;
      $cheap = 10000000;
      $final = null;
      foreach ($carro as $atual){
        if($atual->preco <= $cheap ){
          $smaller = $atual;
          $cheap = $atual->preco;;
        }
      }
    ?>
     <center> <h3><?php echo $smaller->modelo." - Valor: ". $cheap ?> </h3></center>
    <?php } else{ ?>
      <center><h2>Nenhum automovel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- MAIS KM  -->
<div id="container">
  <center><h1>+ KM</h1></center>
    <?php if($carro != NULL ){
      $bigger = NULL;
      $smaller = NULL;
      $expensive = 0;
      $cheap = 10000000;
      $final = null;
      foreach ($carro as $atual){
        if($atual->quilometragem >= $expensive) {
          $bigger = $atual;
          $expensive = $atual->quilometragem;
        }
      }
    ?>
      <center><h3><?php echo $bigger->modelo." - KM: ". $expensive ?> </h3></center>
    <?php } else{ ?>
      <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- MENOS KM   -->
<div id="container">
  <center><h1>- KM</h1></center>
    <?php if($carro != NULL ){
      $bigger = NULL;
      $smaller = NULL;
      $expensive = 0;
      $cheap = 10000000;
      $final = null;
      foreach ($carro as $atual){
        if($atual->quilometragem <= $cheap ){
          $smaller = $atual;
          $cheap = $atual->quilometragem;;
        }
      }
    ?>
      <center><h3><?php echo $smaller->modelo." - KM: ". $cheap ?> </h3></center>
    <?php } else{ ?>
      <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CAMBIO MANUAL   -->
<div id="container">
  <center><h1> CAMBIO MANUAL</h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->cambio == "Manual") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automóvel manual cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
         <center> <h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CAMBIO AUTOMÁTICO   -->
<div id="container">
  <center><h1> CAMBIO AUTOMÁTICO</h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->cambio == "Automático") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automovel automático cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
          <center><h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CARROS À GASOLINA   -->
<div id="container">
  <center><h1> CARROS À GASOLINA </h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->combustivel == "Gasolina") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automovel à gasolina cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
          <center><h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CARROS À DIESEL   -->
<div id="container">
  <center><h1> CARROS À DIESEL </h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->combustivel == "Diesel") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automovel à diesel cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
          <center><h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CARROS À ÁLCOOL   -->
<div id="container">
  <center><h1> CARROS À ÁLCOOL </h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->combustivel == "Álcool") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automovel à álcool cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
          <center><h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CARROS FLEX   -->
<div id="container">
  <center><h1> CARROS FLEX </h1></center>
    <?php if($carro != NULL ){
          $vet = [];
          foreach ($carro as $atual) {
            if($atual->combustivel == "Flex") array_push($vet,$atual);
          }
      } else{ ?>
      <center><h2>Nenhum automovel flex cadastrado.</h2></center>
    <?php } ?>
    <?php
      if(count($vet)>0){
        foreach ($vet as $atual) { ?>
          <center><h3> Modelo: <?php echo $atual->modelo ?></h3></center>
        <?php } ?>
    <?php } else{ ?> <center><h2>Nenhum automóvel cadastrado no nosso sistema!</h2></center>
    <?php } ?>
</div>

<!-- CADASTRO -->
<div id="container">
  <h1>INSERT</h1>
  <div id="body">
    <?php
     echo form_open_multipart('controller/insertzin');
     // MODELO
    echo '<div class="input-field">';
    $modelo = ['id'=>'modelo','name'=>'modelo','class'=>'validate','type'=>'text','minlength'=>'1','maxlength'=>'128','required'=>''];
    echo form_input($modelo);
    echo form_label('Modelo','modelo');
    echo '</div>';
    
    // MARCA
    echo '<div class="input-field">';
    $m = ['Acura'=>'Acura','Audi'=>'Audi','BMW'=>'BMW','Chevrolet'=>'Chevrolet','Citroën'=>'Citroën','Dodge'=>'Dodge','Ferrari'=>'Ferrari','Fiat'=>'Fiat','Ford'=>'Ford','Honda'=>'Honda','Hyundai'=>'Hyundai','Jaguar'=>'Jaguar','Jeep'=>'Jeep','Kia Motors'=>'Kia Motors','Koenigsegg'=>'Koenigsegg','Lamborghini'=>'Lamborghini','Land Rover'=>'Land Rover','Lexus'=>'Lexus','Mazda'=>'Mazda','Mercedez-Benz'=>'Mercedes-Benz','MINI'=>'MINI','Mitsubishi'=>'Mitsubishi','Nissan'=>'Nissan','Peugeot'=>'Peugeot','Porsche'=>'Porsche','Renault'=>'Renault','Seat'=>'Seat','Subaru'=>'Subaru','Suzuki'=>'Suzuki','Toyota'=>'Toyota','Volkswagen'=>'Volkswagen','Volvo'=>'Volvo'];
    $marca = [ 'id'=>'marca','name'=>'marca'];
    echo form_dropdown('marca', $m, 'Chevrolet', $marca);
    echo form_label('Marca');
    echo '</div>';

    // QUILOMETRAGEM
    echo '<div class="input-field">';
    $km = ['id'=>'quilometragem','name'=>'quilometragem','class'=>'validate','type'=>'number','min'=>'0','required'=>''];
    echo form_input($km);
    echo form_label('Quilometragem','quilometragem');
    echo '</div>';

    // CÂMBIO
    echo '<div class="input-field">';
    $opts = ['Manual'=>'Manual','Automático'=>'Automático'];
    $cambio = ['id'=>'cambio','name'=>'cambio'];
    echo form_dropdown('cambio', $opts, 'Automático', $cambio);
    echo form_label('Câmbio');
    echo '</div>';

    // COMBUSTÍVEL
    echo '<div class="input-field">';
    $opts = ['Gasolina'=>'Gasolina','Álcool'=>'Álcool','Diesel'=>'Diesel','Flex'=>'Flex'];
    $cb = ['id'=>'combustivel','name'=>'combustivel'];
    echo form_dropdown('combustivel', $opts, 'Gasolina', $cb);
    echo form_label('Combustível');
    echo '</div>';

    // COR
    echo '<div class="input-field">';
    $cor = ['id'=>'cor','name'=>'cor','class'=>'validate','type'=>'text','maxlength'=>'64','required'=>''];
    echo form_input($cor);
    echo form_label('Cor','cor');
    echo '</div>';
 
    // ANO
    echo '<div class="input-field">';
    $ano = ['id'=>'ano','name'=>'ano','class'=>'validate','type'=>'number','min'=>'1750','max'=>date('Y'),'required'=>''];
    echo form_input($ano);
    echo form_label('Ano','ano');
    echo '</div>';

    // CIDADE
    echo '<div class="input-field">';
    $cidade = ['id'=>'cidade','name'=>'cidade','class'=>'validate','type'=>'text','maxlength'=>'127','required'=>''];
    echo form_input($cidade);
    echo form_label('Cidade','cidade');
    echo '</div>';

    // PREÇO
    echo '<div class="input-field">';
    $preco = ['id'=>'preco','name'=>'preco','class'=>'validate','type'=>'number','min'=>'5000','max'=>'900000','required'=>''];
    echo form_input($preco);
    echo form_label('Preço','preco');
    echo '</div>';

    echo "<br>";
    echo '<button type="submit">Enviar</button>'; 
    echo form_close();
    echo "<br>";
  ?>
  </div>
</div>

<!-- DELETE USER -->
<div id="container">
  <h1>DELETE USER</h1>
  <div id="body">
    <?php
     echo form_open_multipart('controller/removeUser');
    echo '<div class="input-field">';
    $id = ['id'=>'id','name'=>'id','class'=>'validate','type'=>'text','minlength'=>'1','maxlength'=>'128','required'=>''];
    echo form_input($id);
    echo form_label('Id do usuário','id');
    echo '</div>';
    echo "<br>";
    echo '<button type="submit">Enviar</button>'; 
    echo form_close();
    echo "<br>";
  ?>
  </div>
</div>

<!-- DELETE MODEL -->
<div id="container">
  <h1>DELETE MODEL</h1>
  <div id="body">
    <?php
     echo form_open_multipart('controller/removeModel');
    echo '<div class="input-field">';
    $modelo = ['id'=>'modelo','name'=>'modelo','class'=>'validate','type'=>'text','minlength'=>'1','maxlength'=>'128','required'=>''];
    echo form_input($modelo);
    echo form_label('Modelo','modelo');
    echo '</div>';
    echo "<br>";
    echo '<button type="submit">Enviar</button>'; 
    echo form_close();
    echo "<br>";
  ?>
  </div>
</div>

<!-- DELETE BRAND -->
<div id="container">
  <h1>DELETE BRAND</h1>
  <div id="body">
    <?php
     echo form_open_multipart('controller/removeBrand');
     $m = ['Acura'=>'Acura','Audi'=>'Audi','BMW'=>'BMW','Chevrolet'=>'Chevrolet','Citroën'=>'Citroën','Dodge'=>'Dodge','Ferrari'=>'Ferrari','Fiat'=>'Fiat','Ford'=>'Ford','Honda'=>'Honda','Hyundai'=>'Hyundai','Jaguar'=>'Jaguar','Jeep'=>'Jeep','Kia Motors'=>'Kia Motors','Koenigsegg'=>'Koenigsegg','Lamborghini'=>'Lamborghini','Land Rover'=>'Land Rover','Lexus'=>'Lexus','Mazda'=>'Mazda','Mercedez-Benz'=>'Mercedes-Benz','MINI'=>'MINI','Mitsubishi'=>'Mitsubishi','Nissan'=>'Nissan','Peugeot'=>'Peugeot','Porsche'=>'Porsche','Renault'=>'Renault','Seat'=>'Seat','Subaru'=>'Subaru','Suzuki'=>'Suzuki','Toyota'=>'Toyota','Volkswagen'=>'Volkswagen','Volvo'=>'Volvo'];
    $marca = [ 'id'=>'marca','name'=>'marca'];
    echo form_dropdown('marca', $m, 'Chevrolet', $marca);
    echo form_label('Marca');
    echo "<br> <br>";
    echo '<button type="submit">Enviar</button>'; 
    echo form_close();
    echo "<br>";
  ?>
  </div>
</div>

</body>
<form action="login/">
    <input type="submit" value="Sair" 
         name="Submit"/>
</form>
<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</html>